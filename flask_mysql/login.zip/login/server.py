# import all controllers that will be using an app route
from flask_app.controllers import login_controller

# without app server will NOT run
from flask_app import app

if __name__ == "__main__":
    app.run(debug=True)
    