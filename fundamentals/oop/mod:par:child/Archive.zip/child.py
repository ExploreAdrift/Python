import parent

__name__
print(__name__)
