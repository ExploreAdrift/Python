from flask_app.config.mysqlconnection import connectToMySQL


from flask import flash


from flask_app import DATABASE


class Sight:
    def __init__(self, data):
        self.id = data["id"]
        self.location = data["location"]
        self.what_happened = data["what_happened"]
        self.date_sight = data["date_sight"]
        self.num_sasq = data["num_sasq"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]
        self.user_id = data["user_id"]

    @classmethod
    def new_sight(cls, data):
        query = "INSERT INTO sight (location, what_happened, data_sight, num_sasq, created_at, updated_at, user_id)"
        query = "VALUES (%(location)s,%(what_happened)s, %(date_sight)s, %(num_sasq)s, NOW(), NOW(), %(user_id)s);"
        result = connectToMySQL(DATABASE).query_db(query, data)
        return result

    @classmethod
    def get_all_sight(cls):
        query = 'SELECT * FROM sight;'
        result = connectToMySQL(DATABASE).query_db(query)
        sight = []
        for row in result:
            sight.append(cls(row))
        return sight

    @classmethod
    def edit_sight(cls, data):
        # make sure to check all your mogrify text to ensure it matches the column names in the table
        query = 'UPDATE sight SET location = %(location)s, what_happened = %(what_happened)s, date_sight = %(date_sight)s,'
        query += 'num_sasq = %(num_sasq)s, updated_at = NOW() WHERE id = %(id)s;'
        result = connectToMySQL(DATABASE).query_db(query, data)
        return result

    @classmethod
    def get_one(cls, data):
        query = "SELECT * FROM sight WHERE id=%(id)s;"
        result = connectToMySQL(DATABASE).query_db(query, data)
        return cls(result[0])

    @classmethod
    def delete(cls, data):
        query = "DELETE FROM sight WHERE id = %(id)s;"
        result = connectToMySQL(DATABASE).query_db(query, data)
        return result

    @staticmethod
    def validate_sight_present(user):
        print(user)
        if not len(user['location']) > 0:
            flash('You must enter a location!')
            return False
        if not len(user['what_happened']) > 0:
            flash('You must enter a description on what happened!')
            return False
        if not len(user['date_sight']) > 0:
            flash('You must enter the date  the beast was sighted!')
            return False
        if not user['num_sasq']:
            flash('You must enter how many there were!')
            return False
        return True

    @staticmethod
    def sight_length(user):
        if not len(user['location']) > 2:
            flash('Location must be at least 3 charaters!')
            return False
        if not len(user['what_happened']) > 2:
            flash('What happened must be at least 3 charaters!')
            return False
        if not len(user['date_sight']) > 2:
            flash('Number sighted must be at least 3 charaters!')
            return False
        return True
