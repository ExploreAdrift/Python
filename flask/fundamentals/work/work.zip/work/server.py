from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def first_one():
    return render_template("index.html", num=8, row=8)


@app.route('/4')
def second_one():
    return render_template("index.html", num=8, row=4)


@app.route('/<int:x>/<int:y>')
def third_one(x, y):
    return render_template("index.html", num=x, row=y)


@app.route('/<x>/<y>/<color1>/<color2>')
def fourth_one(x, y, color, color2):
    return render_template("index.html", num=8)


if __name__ == "__main__":
    app.run(debug=True)
